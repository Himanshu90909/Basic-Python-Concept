# Tkinter Calculator
# Assignment: GUI Calculator using Tkinter

import tkinter as tk

# ── Main Window ──────────────────────────────────────────
root = tk.Tk()
root.title("Calculator")
root.resizable(False, False)
root.configure(bg="#2b2b2b")

# ── Display Entry ─────────────────────────────────────────
display_var = tk.StringVar()

display = tk.Entry(
    root,
    textvariable=display_var,
    font=("Arial", 24, "bold"),
    bd=0,
    relief="flat",
    justify="right",
    bg="#1e1e1e",
    fg="#ffffff",
    insertbackground="#ffffff"
)
display.grid(row=0, column=0, columnspan=4, padx=15, pady=(15, 10), ipady=18, sticky="we")

# ── Button Click Handler ──────────────────────────────────
def button_click(value):
    current = display_var.get()
    display_var.set(current + str(value))

def clear_display():
    display_var.set("")

def calculate():
    try:
        expression = display_var.get()
        result = eval(expression)
        # Show integer if result is whole number
        if result == int(result):
            display_var.set(int(result))
        else:
            display_var.set(round(result, 6))
    except ZeroDivisionError:
        display_var.set("Error: Div by 0")
    except Exception:
        display_var.set("Error")

# ── Button Layout ─────────────────────────────────────────
# (label, row, col, colspan, action)
buttons = [
    ("C",  1, 0, 1, clear_display),
    ("/",  1, 1, 1, lambda: button_click("/")),
    ("*",  1, 2, 1, lambda: button_click("*")),
    ("-",  1, 3, 1, lambda: button_click("-")),

    ("7",  2, 0, 1, lambda: button_click("7")),
    ("8",  2, 1, 1, lambda: button_click("8")),
    ("9",  2, 2, 1, lambda: button_click("9")),
    ("+",  2, 3, 1, lambda: button_click("+")),

    ("4",  3, 0, 1, lambda: button_click("4")),
    ("5",  3, 1, 1, lambda: button_click("5")),
    ("6",  3, 2, 1, lambda: button_click("6")),
    ("=",  3, 3, 1, calculate),           # spans rows 3-4

    ("1",  4, 0, 1, lambda: button_click("1")),
    ("2",  4, 1, 1, lambda: button_click("2")),
    ("3",  4, 2, 1, lambda: button_click("3")),

    ("0",  5, 0, 2, lambda: button_click("0")),
    (".",  5, 2, 1, lambda: button_click(".")),
]

# Color scheme
COLOR = {
    "digit":  {"bg": "#3c3c3c", "fg": "#ffffff", "active": "#505050"},
    "op":     {"bg": "#ff9500", "fg": "#ffffff", "active": "#ffaa33"},
    "clear":  {"bg": "#d4000f", "fg": "#ffffff", "active": "#ff1a2a"},
    "equal":  {"bg": "#ff9500", "fg": "#ffffff", "active": "#ffaa33"},
}

def get_style(label):
    if label == "C":
        return COLOR["clear"]
    elif label == "=":
        return COLOR["equal"]
    elif label in ("+", "-", "*", "/"):
        return COLOR["op"]
    else:
        return COLOR["digit"]

for (label, row, col, colspan, action) in buttons:
    style = get_style(label)
    btn = tk.Button(
        root,
        text=label,
        font=("Arial", 18, "bold"),
        bd=0,
        relief="flat",
        bg=style["bg"],
        fg=style["fg"],
        activebackground=style["active"],
        activeforeground=style["fg"],
        cursor="hand2",
        command=action
    )
    btn.grid(
        row=row, column=col, columnspan=colspan,
        padx=5, pady=5,
        ipadx=10, ipady=16,
        sticky="nsew"
    )

# "=" button spans rows 3 and 4
eq_btn = tk.Button(
    root,
    text="=",
    font=("Arial", 18, "bold"),
    bd=0,
    relief="flat",
    bg=COLOR["equal"]["bg"],
    fg=COLOR["equal"]["fg"],
    activebackground=COLOR["equal"]["active"],
    activeforeground=COLOR["equal"]["fg"],
    cursor="hand2",
    command=calculate
)
eq_btn.grid(row=3, column=3, rowspan=2, padx=5, pady=5, ipadx=10, ipady=16, sticky="nsew")

# ── Make columns & rows resize evenly ────────────────────
for i in range(4):
    root.columnconfigure(i, weight=1)
for i in range(1, 6):
    root.rowconfigure(i, weight=1)

# ── Keyboard Support ──────────────────────────────────────
def key_press(event):
    key = event.char
    if key in "0123456789.+-*/":
        button_click(key)
    elif key in ("\r", "="):
        calculate()
    elif key in ("\x08",):       # Backspace
        display_var.set(display_var.get()[:-1])
    elif key.lower() == "c":
        clear_display()

root.bind("<Key>", key_press)

# ── Run ───────────────────────────────────────────────────
root.mainloop()
