# Task 2: Demonstrate List Slicing

numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

first_five = numbers[:5]

reversed_list = first_five[::-1]

print("Original List:", numbers)
print("First Five Elements:", first_five)
print("Reversed List:", reversed_list)
