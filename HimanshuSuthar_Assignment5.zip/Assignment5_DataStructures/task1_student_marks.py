# Task 1: Create a Dictionary of Student Marks

student_marks = {
    "Alice": 85,
    "Bob": 92,
    "Charlie": 78,
    "Diana": 95,
    "Eve": 88
}

name = input("Enter the student's name: ")

if name in student_marks:
    print("Marks of", name, ":", student_marks[name])
else:
    print("Student", name, "not found in the records.")
