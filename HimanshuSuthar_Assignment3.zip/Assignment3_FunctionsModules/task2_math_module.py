# Task 2: Using the Math Module for Calculations

import math

number = float(input("Enter a number: "))

square_root = math.sqrt(number)
natural_log = math.log(number)
sine_value  = math.sin(number)

print("Square Root of", number, ":", square_root)
print("Natural Logarithm of", number, ":", natural_log)
print("Sine of", number, ":", sine_value)
