# Task 1: Calculate Factorial Using a Function

def factorial(number):
    result = 1
    for i in range(1, number + 1):
        result = result * i
    return result

number = 5
print("Factorial of", number, "is:", factorial(number))
