# Task 1: Read a File and Handle Errors

try:
    file = open("sample.txt", "r")
    print("File content:")
    for line in file:
        print(line, end="")
    file.close()

except FileNotFoundError:
    print("Error: The file 'sample.txt' does not exist.")
