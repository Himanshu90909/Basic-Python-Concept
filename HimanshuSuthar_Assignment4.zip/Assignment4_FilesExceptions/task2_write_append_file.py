# Task 2: Write and Append Data to a File

# Step 1: Take user input and write to output.txt
user_input = input("Enter some text to write to the file: ")

file = open("output.txt", "w")
file.write(user_input + "\n")
file.close()

# Step 2: Append additional data to the same file
file = open("output.txt", "a")
file.write("This line is appended to the file.\n")
file.close()

# Step 3: Read and display the final content
print("\nFinal content of output.txt:")
file = open("output.txt", "r")
for line in file:
    print(line, end="")
file.close()
