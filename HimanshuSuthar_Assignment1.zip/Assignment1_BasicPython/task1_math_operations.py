# Task 1: Perform Basic Mathematical Operations

num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))

addition = num1 + num2
subtraction = num1 - num2
multiplication = num1 * num2

print("Addition:", num1, "+", num2, "=", addition)
print("Subtraction:", num1, "-", num2, "=", subtraction)
print("Multiplication:", num1, "*", num2, "=", multiplication)

if num2 != 0:
    division = num1 / num2
    print("Division:", num1, "/", num2, "=", division)
else:
    print("Division: Cannot divide by zero!")
